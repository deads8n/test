# MyProjSite
All HTML for my github site
this is bascilly a project i work on when i have some time to myself in class
its pretty neat.
the only thing I coded was the index.html file, and thats the only thing i actually take credit for. The rest of the stuff has been forked from other gh reops.
